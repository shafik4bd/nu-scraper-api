<?php defined('ABSPATH') || exit;
// Variables available: $notices, $a (shortcode atts)
$show_date = ($a['show_date'] !== 'no');
$show_no   = ($a['show_no']   !== 'no');
?>
<div class="nuns-public-wrap">
  <?php if (!empty($a['title'])): ?>
  <div class="nuns-pub-header">
    <h2 class="nuns-pub-title"><?php echo esc_html($a['title']); ?></h2>
    <span class="nuns-pub-count"><?php echo count($notices); ?> Notices</span>
  </div>
  <?php endif; ?>

  <?php if (empty($notices)): ?>
    <p class="nuns-pub-empty">No notices available at this time.</p>
  <?php else: ?>

  <!-- Search Box -->
  <div class="nuns-pub-search-wrap">
    <input type="text" id="nuns-pub-search" placeholder="🔍  Search notices…" class="nuns-pub-search">
  </div>

  <div class="nuns-pub-table-wrap">
    <table class="nuns-pub-table" id="nuns-pub-table">
      <thead>
        <tr>
          <?php if ($show_no): ?><th class="nuns-th-no">No.</th><?php endif; ?>
          <th class="nuns-th-title">Notice Title</th>
          <?php if ($show_date): ?><th class="nuns-th-date">Date</th><?php endif; ?>
          <th class="nuns-th-pdf">PDF</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($notices as $i => $n): ?>
        <tr class="nuns-pub-row">
          <?php if ($show_no): ?><td class="nuns-td-no"><?php echo $i+1; ?></td><?php endif; ?>
          <td class="nuns-td-title"><?php echo esc_html($n->title); ?></td>
          <?php if ($show_date): ?><td class="nuns-td-date"><?php echo esc_html($n->publish_date ?: '—'); ?></td><?php endif; ?>
          <td class="nuns-td-pdf">
            <?php
            // Use local PDF if available, otherwise original URL
            $pdf_url = ($n->local_pdf && file_exists($n->local_pdf))
                ? esc_url(str_replace(ABSPATH, site_url('/'), $n->local_pdf))
                : esc_url($n->pdf_url);
            // For local: build proper URL
            if ($n->local_pdf && file_exists($n->local_pdf)) {
                $upload   = wp_upload_dir();
                $rel      = str_replace($upload['basedir'], $upload['baseurl'], $n->local_pdf);
                $pdf_url  = esc_url($rel);
            }
            ?>
            <a href="<?php echo $pdf_url; ?>" target="_blank" rel="noopener" class="nuns-pub-pdf-btn" title="Download PDF">
              <span class="nuns-pub-pdf-icon">
                <svg viewBox="0 0 56 64" width="40" height="46" xmlns="http://www.w3.org/2000/svg">
                  <rect width="56" height="64" rx="5" fill="#fff0f0"/>
                  <path d="M6 2h28l14 14v44a4 4 0 01-4 4H6a4 4 0 01-4-4V6a4 4 0 014-4z" fill="#EF4444"/>
                  <path d="M34 2l14 14H38a4 4 0 01-4-4V2z" fill="#fca5a5"/>
                  <text x="28" y="46" text-anchor="middle" fill="white" font-size="13" font-weight="bold" font-family="Arial,sans-serif">PDF</text>
                </svg>
              </span>
              <span class="nuns-pub-pdf-label">Download</span>
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div class="nuns-pub-footer">
    Source: <a href="https://www.nu.ac.bd" target="_blank" rel="noopener">National University Bangladesh</a>
  </div>
  <?php endif; ?>
</div>

<script>
(function(){
  var inp = document.getElementById('nuns-pub-search');
  if(!inp) return;
  inp.addEventListener('input', function(){
    var q = this.value.toLowerCase();
    document.querySelectorAll('.nuns-pub-row').forEach(function(row){
      var txt = row.querySelector('.nuns-td-title').textContent.toLowerCase();
      row.style.display = txt.includes(q) ? '' : 'none';
    });
  });
})();
</script>
