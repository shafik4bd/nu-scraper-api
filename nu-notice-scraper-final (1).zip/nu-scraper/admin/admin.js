(function ($) {
  'use strict';

  var ajax = NUNS.ajax, nonce = NUNS.nonce;

  /* ── Helper: show alert ──────────────────────── */
  function showAlert(msg, type) {
    var $el = $('#nuns-alert');
    $el.removeClass('ok err').addClass(type === 'error' ? 'err' : 'ok').html(msg).show();
    $('html,body').animate({ scrollTop: $el.offset().top - 60 }, 300);
    setTimeout(function () { $el.fadeOut(); }, 6000);
  }

  function setLoading($btn, loading) {
    if (loading) {
      $btn.data('orig', $btn.html()).html('<span class="nuns-spin"></span> Working…').prop('disabled', true);
    } else {
      $btn.html($btn.data('orig')).prop('disabled', false);
    }
  }

  /* ── Scrape Now ──────────────────────────────── */
  $('#nuns-btn-scrape').on('click', function () {
    var $btn = $(this);
    setLoading($btn, true);
    $.post(ajax, { action: 'nuns_scrape', nonce: nonce }, function (res) {
      setLoading($btn, false);
      if (res.success) {
        showAlert('✅ ' + res.data.message + ' — Page will refresh…', 'success');
        setTimeout(function () { location.reload(); }, 2000);
      } else {
        showAlert('❌ Error: ' + (res.data || 'Unknown error'), 'error');
      }
    }).fail(function () {
      setLoading($btn, false);
      showAlert('❌ Network error. Please try again.', 'error');
    });
  });

  /* ── Download single PDF ─────────────────────── */
  $(document).on('click', '.nuns-dl-pdf', function () {
    var $btn = $(this), id = $btn.data('id');
    setLoading($btn, true);
    $.post(ajax, { action: 'nuns_download_pdf', nonce: nonce, id: id }, function (res) {
      if (res.success) {
        $btn.closest('td').html('<span class="nuns-badge nuns-badge-ok">✅ Saved</span>');
      } else {
        setLoading($btn, false);
        showAlert('❌ Download failed: ' + (res.data || ''), 'error');
      }
    });
  });

  /* ── Bulk download PDFs ──────────────────────── */
  $('#nuns-btn-bulk-dl').on('click', function () {
    if (!confirm('Download all pending PDFs to your server? This may take a while.')) return;
    var $btn = $(this);
    setLoading($btn, true);
    $.post(ajax, { action: 'nuns_bulk_download', nonce: nonce }, function (res) {
      setLoading($btn, false);
      if (res.success) {
        showAlert('✅ Downloaded ' + res.data.downloaded + ' PDF(s) to server.', 'success');
        setTimeout(function () { location.reload(); }, 1500);
      } else {
        showAlert('❌ Bulk download failed.', 'error');
      }
    });
  });

  /* ── Delete single notice ────────────────────── */
  $(document).on('click', '.nuns-del-notice', function () {
    if (!confirm('Delete this notice?')) return;
    var $btn = $(this), id = $btn.data('id');
    $.post(ajax, { action: 'nuns_delete_notice', nonce: nonce, id: id }, function (res) {
      if (res.success) {
        $('#nuns-row-' + id).fadeOut(300, function () { $(this).remove(); });
      }
    });
  });

  /* ── Delete all ──────────────────────────────── */
  $('#nuns-btn-delete-all').on('click', function () {
    if (!confirm('⚠️ Delete ALL notices from the database? This cannot be undone.')) return;
    var $btn = $(this);
    setLoading($btn, true);
    $.post(ajax, { action: 'nuns_delete_all', nonce: nonce }, function (res) {
      if (res.success) {
        showAlert('🗑 All notices deleted.', 'success');
        setTimeout(function () { location.reload(); }, 1200);
      } else {
        setLoading($btn, false);
      }
    });
  });

  /* ── Copy shortcode ──────────────────────────── */
  $(document).on('click', '.nuns-copy-btn', function () {
    var text = $(this).data('copy') || $(this).prev('.nuns-sc-code').text();
    navigator.clipboard.writeText(text).then(() => {
      var $b = $(this), orig = $b.text();
      $b.text('Copied!');
      setTimeout(function () { $b.text(orig); }, 1500);
    });
  });

})(jQuery);
