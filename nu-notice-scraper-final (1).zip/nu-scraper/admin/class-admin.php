<?php
defined( 'ABSPATH' ) || exit;

class NUNS_Admin {

    public function __construct() {
        add_action( 'admin_menu',            [ $this, 'menus' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
        // AJAX
        add_action( 'wp_ajax_nuns_scrape',        [ $this, 'ajax_scrape' ] );
        add_action( 'wp_ajax_nuns_download_pdf',  [ $this, 'ajax_download_pdf' ] );
        add_action( 'wp_ajax_nuns_bulk_download', [ $this, 'ajax_bulk_download' ] );
        add_action( 'wp_ajax_nuns_delete_notice', [ $this, 'ajax_delete' ] );
        add_action( 'wp_ajax_nuns_delete_all',    [ $this, 'ajax_delete_all' ] );
    }

    /* ── Menus ──────────────────────────────────── */
    public function menus() {
        add_menu_page(
            'NU Notice Scraper', 'NU Notices', 'manage_options',
            'nuns-notices', [ $this, 'page_notices' ],
            'dashicons-media-document', 25
        );
        add_submenu_page( 'nuns-notices', 'All Notices', 'All Notices', 'manage_options', 'nuns-notices', [ $this, 'page_notices' ] );
        add_submenu_page( 'nuns-notices', 'Settings',    'Settings',    'manage_options', 'nuns-settings', [ $this, 'page_settings' ] );
    }

    /* ── Enqueue ─────────────────────────────────── */
    public function enqueue( $hook ) {
        if ( ! in_array( $hook, ['toplevel_page_nuns-notices', 'nu-notices_page_nuns-settings'] ) ) return;
        wp_enqueue_style( 'nuns-admin', NUNS_URL . 'admin/admin.css', [], NUNS_VER );
        wp_enqueue_script( 'nuns-admin', NUNS_URL . 'admin/admin.js', ['jquery'], NUNS_VER, true );
        wp_localize_script( 'nuns-admin', 'NUNS', [
            'ajax' => admin_url('admin-ajax.php'),
            'nonce'=> wp_create_nonce('nuns_nonce'),
        ]);
    }

    /* ── Pages ──────────────────────────────────── */
    public function page_notices() {
        $search = sanitize_text_field( $_GET['s'] ?? '' );
        $paged  = max( 1, (int)($_GET['paged'] ?? 1) );
        $per    = 30;
        $total  = NUNS_DB::count( $search );
        $rows   = NUNS_DB::get_list([ 'search'=>$search, 'limit'=>$per, 'offset'=>($paged-1)*$per ]);
        $last   = get_option('nuns_last_scrape', []);
        $next   = wp_next_scheduled('nuns_cron_scrape');
        include NUNS_DIR . 'admin/views/notices.php';
    }

    public function page_settings() {
        if ( isset($_POST['nuns_save_settings']) && check_admin_referer('nuns_settings') ) {
            update_option( 'nuns_auto_download_pdf', isset($_POST['auto_dl']) ? 1 : 0 );
            update_option( 'nuns_shortcode_title',   sanitize_text_field($_POST['sc_title'] ?? '') );
            update_option( 'nuns_shortcode_limit',   (int)($_POST['sc_limit'] ?? 0) );
            echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
        }
        $auto_dl   = get_option('nuns_auto_download_pdf', 0);
        $sc_title  = get_option('nuns_shortcode_title', 'National University – Latest Notices');
        $sc_limit  = get_option('nuns_shortcode_limit', 0);
        include NUNS_DIR . 'admin/views/settings.php';
    }

    /* ── AJAX ───────────────────────────────────── */
    private function verify() {
        check_ajax_referer('nuns_nonce','nonce');
        if ( ! current_user_can('manage_options') ) wp_send_json_error('Unauthorized',403);
    }

    public function ajax_scrape() {
        $this->verify();
        $r = NUNS_Scraper::run();
        if ( get_option('nuns_auto_download_pdf',0) ) {
            NUNS_Scraper::download_all_pdfs();
        }
        wp_send_json_success($r);
    }

    public function ajax_download_pdf() {
        $this->verify();
        $id  = (int)$_POST['id'];
        $res = NUNS_Scraper::download_pdf($id);
        if ( is_wp_error($res) ) wp_send_json_error($res->get_error_message());
        wp_send_json_success($res);
    }

    public function ajax_bulk_download() {
        $this->verify();
        $done = NUNS_Scraper::download_all_pdfs();
        wp_send_json_success(['downloaded'=>$done]);
    }

    public function ajax_delete() {
        $this->verify();
        NUNS_DB::delete( (int)$_POST['id'] );
        wp_send_json_success();
    }

    public function ajax_delete_all() {
        $this->verify();
        global $wpdb;
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}nuns_notices");
        wp_send_json_success(['message'=>'All notices deleted.']);
    }
}
