<?php defined('ABSPATH') || exit; ?>
<div class="wrap nuns-wrap">
  <div class="nuns-header">
    <div class="nuns-header-left">
      <h1 class="nuns-title"><span class="nuns-logo">⚙️</span> Settings</h1>
      <p class="nuns-subtitle">Configure NU Notice Scraper behaviour</p>
    </div>
  </div>

  <div class="nuns-card nuns-settings-card">
    <form method="post">
      <?php wp_nonce_field('nuns_settings'); ?>

      <table class="nuns-settings-table">
        <tr>
          <th>Auto-download PDFs</th>
          <td>
            <label class="nuns-toggle">
              <input type="checkbox" name="auto_dl" value="1" <?php checked(1, $auto_dl); ?>>
              <span class="nuns-toggle-slider"></span>
            </label>
            <p class="description">Automatically download PDF files to your server after each scrape.</p>
          </td>
        </tr>
        <tr>
          <th>Shortcode Table Title</th>
          <td>
            <input type="text" name="sc_title" value="<?php echo esc_attr($sc_title); ?>" class="nuns-input-wide" placeholder="National University – Latest Notices">
            <p class="description">Default title shown above the public notice table.</p>
          </td>
        </tr>
        <tr>
          <th>Shortcode Limit</th>
          <td>
            <input type="number" name="sc_limit" value="<?php echo (int)$sc_limit; ?>" min="0" class="nuns-input-sm">
            <p class="description">Limit number of notices shown. Set 0 for all.</p>
          </td>
        </tr>
        <tr>
          <th>Scrape Interval</th>
          <td>
            <strong>Every 5 minutes</strong> (via WordPress Cron)
            <p class="description">For accurate timing, ensure WP-Cron is triggered regularly. Consider using a server cron: <code>*/5 * * * * curl <?php echo esc_url(site_url('/?doing_wp_cron')); ?></code></p>
          </td>
        </tr>
        <tr>
          <th>Shortcode Usage</th>
          <td>
            <div class="nuns-sc-examples">
              <div><code>[nu_notices]</code> — Show all notices</div>
              <div><code>[nu_notices limit="20"]</code> — Show latest 20</div>
              <div><code>[nu_notices title="My Notices" limit="10"]</code> — Custom title</div>
              <div><code>[nu_notices show_date="no"]</code> — Hide date column</div>
            </div>
          </td>
        </tr>
        <tr>
          <th>PDF Storage Path</th>
          <td>
            <?php $u = wp_upload_dir(); ?>
            <code><?php echo esc_html($u['basedir'].'/'.NUNS_PDF_SUBDIR.'/'); ?></code>
            <p class="description">Downloaded PDFs are stored here.</p>
          </td>
        </tr>
      </table>

      <div class="nuns-settings-footer">
        <button type="submit" name="nuns_save_settings" class="nuns-btn nuns-btn-primary">Save Settings</button>
      </div>
    </form>
  </div>
</div>
