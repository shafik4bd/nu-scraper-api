<?php defined('ABSPATH') || exit; ?>
<div class="wrap nuns-wrap">

  <!-- ── Page Header ── -->
  <div class="nuns-header">
    <div class="nuns-header-left">
      <h1 class="nuns-title">
        <span class="nuns-logo">🎓</span>
        NU Notice Scraper
      </h1>
      <p class="nuns-subtitle">Scraping from <a href="<?php echo esc_url(NUNS_SOURCE); ?>" target="_blank">nu.ac.bd</a> every 5 minutes</p>
    </div>
    <div class="nuns-header-right">
      <button id="nuns-btn-scrape" class="nuns-btn nuns-btn-primary">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M1 4v6h6M23 20v-6h-6"/><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/></svg>
        Scrape Now
      </button>
      <button id="nuns-btn-bulk-dl" class="nuns-btn nuns-btn-secondary">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        Download All PDFs
      </button>
    </div>
  </div>

  <!-- ── Stats ── -->
  <div class="nuns-stats">
    <div class="nuns-stat">
      <div class="nuns-stat-val"><?php echo NUNS_DB::count(); ?></div>
      <div class="nuns-stat-lbl">Total Notices</div>
    </div>
    <div class="nuns-stat">
      <div class="nuns-stat-val"><?php echo !empty($last['status']) && $last['status']==='success' ? '✅' : (empty($last) ? '—' : '❌'); ?></div>
      <div class="nuns-stat-lbl">Last Status</div>
    </div>
    <div class="nuns-stat">
      <div class="nuns-stat-val"><?php echo !empty($last['time']) ? human_time_diff(strtotime($last['time'])).' ago' : '—'; ?></div>
      <div class="nuns-stat-lbl">Last Scrape</div>
    </div>
    <div class="nuns-stat">
      <div class="nuns-stat-val"><?php echo $next ? human_time_diff(time(), $next) : 'Not set'; ?></div>
      <div class="nuns-stat-lbl">Next Scrape</div>
    </div>
    <div class="nuns-stat nuns-stat-sc">
      <div class="nuns-stat-sc-label">Shortcode</div>
      <code class="nuns-sc-code">[nu_notices]</code>
      <button class="nuns-copy-btn" data-copy="[nu_notices]">Copy</button>
    </div>
  </div>

  <!-- ── Scrape result banner ── -->
  <div id="nuns-alert" class="nuns-alert" style="display:none"></div>

  <!-- ── Last scrape info ── -->
  <?php if (!empty($last['message'])): ?>
  <div class="nuns-last-msg <?php echo $last['status']==='success' ? 'nuns-msg-ok' : 'nuns-msg-err'; ?>">
    <strong><?php echo $last['status']==='success' ? '✅' : '❌'; ?></strong>
    <?php echo esc_html($last['message']); ?>
    <?php if (!empty($last['time'])): ?>— <em><?php echo esc_html($last['time']); ?></em><?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- ── Toolbar ── -->
  <div class="nuns-toolbar">
    <form method="get" class="nuns-search">
      <input type="hidden" name="page" value="nuns-notices">
      <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="🔍  Search title…" class="nuns-search-input">
      <button class="nuns-btn nuns-btn-sm">Search</button>
      <?php if($search): ?><a href="?page=nuns-notices" class="nuns-btn nuns-btn-sm nuns-btn-ghost">✕ Clear</a><?php endif; ?>
    </form>
    <div class="nuns-toolbar-right">
      <span class="nuns-count-label">Showing <strong><?php echo count($rows); ?></strong> of <strong><?php echo $total; ?></strong></span>
      <button id="nuns-btn-delete-all" class="nuns-btn nuns-btn-sm nuns-btn-danger">🗑 Delete All</button>
    </div>
  </div>

  <!-- ── Table ── -->
  <div class="nuns-card">
    <?php if (empty($rows)): ?>
      <div class="nuns-empty">
        <div class="nuns-empty-icon">📭</div>
        <h3>No notices found</h3>
        <p>Click <strong>Scrape Now</strong> to fetch the latest notices from National University.</p>
      </div>
    <?php else: ?>
    <div class="nuns-table-wrap">
      <table class="nuns-table">
        <thead>
          <tr>
            <th class="col-sl">SL</th>
            <th class="col-title">Notice Title</th>
            <th class="col-date">Date</th>
            <th class="col-pdf">PDF Link</th>
            <th class="col-local">Local Copy</th>
            <th class="col-act">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $i => $r): ?>
          <tr id="nuns-row-<?php echo $r->id; ?>">
            <td class="col-sl"><?php echo ($paged-1)*$per + $i + 1; ?></td>
            <td class="col-title">
              <div class="nuns-notice-title"><?php echo esc_html($r->title); ?></div>
              <div class="nuns-notice-meta">Scraped: <?php echo esc_html($r->scraped_at); ?></div>
            </td>
            <td class="col-date">
              <span class="nuns-date"><?php echo esc_html($r->publish_date ?: '—'); ?></span>
            </td>
            <td class="col-pdf">
              <a href="<?php echo esc_url($r->pdf_url); ?>" target="_blank" class="nuns-pdf-thumb" title="Open PDF">
                <svg viewBox="0 0 64 72" xmlns="http://www.w3.org/2000/svg" width="46" height="52">
                  <rect width="64" height="72" rx="6" fill="#fff2f2"/>
                  <path d="M8 4h32l16 16v48a4 4 0 01-4 4H8a4 4 0 01-4-4V8a4 4 0 014-4z" fill="#EF4444" opacity=".9"/>
                  <path d="M40 4l16 16H44a4 4 0 01-4-4V4z" fill="#fca5a5"/>
                  <text x="32" y="52" text-anchor="middle" fill="white" font-size="14" font-weight="bold" font-family="Arial,sans-serif">PDF</text>
                </svg>
              </a>
            </td>
            <td class="col-local">
              <?php if ($r->local_pdf && file_exists($r->local_pdf)): ?>
                <span class="nuns-badge nuns-badge-ok">✅ Saved</span>
              <?php else: ?>
                <button class="nuns-btn nuns-btn-xs nuns-dl-pdf" data-id="<?php echo $r->id; ?>">⬇ Download</button>
              <?php endif; ?>
            </td>
            <td class="col-act">
              <button class="nuns-btn nuns-btn-xs nuns-btn-danger nuns-del-notice" data-id="<?php echo $r->id; ?>">Delete</button>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <?php if ($total > $per): ?>
    <div class="nuns-pagination">
      <?php $pages = ceil($total/$per); for($p=1;$p<=$pages;$p++): ?>
        <a href="<?php echo esc_url(add_query_arg(['paged'=>$p,'s'=>$search])); ?>"
           class="nuns-page <?php echo $p===$paged?'active':''; ?>"><?php echo $p; ?></a>
      <?php endfor; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
  </div><!-- .nuns-card -->
</div><!-- .wrap -->
