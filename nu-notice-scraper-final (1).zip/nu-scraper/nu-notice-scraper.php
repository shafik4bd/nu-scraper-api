<?php
/**
 * Plugin Name:  NU Notice Scraper
 * Description:  Scrapes notices/news from nu.ac.bd every 5 minutes, stores in DB, displays via shortcode.
 * Version:      2.0.0
 * Author:       Your Name
 * Text Domain:  nu-scraper
 * License:      GPL-2.0+
 */

defined( 'ABSPATH' ) || exit;

define( 'NUNS_VER',        '2.0.0' );
define( 'NUNS_DIR',        plugin_dir_path( __FILE__ ) );
define( 'NUNS_URL',        plugin_dir_url( __FILE__ ) );
define( 'NUNS_SOURCE',     'https://www.nu.ac.bd/recent-news-notice.php' );
define( 'NUNS_BASE_URL',   'https://www.nu.ac.bd/' );
define( 'NUNS_PDF_SUBDIR', 'nu-notices' );

/* ── Load classes ───────────────────────────────── */
require_once NUNS_DIR . 'includes/class-db.php';
require_once NUNS_DIR . 'includes/class-scraper.php';
require_once NUNS_DIR . 'includes/class-shortcode.php';
require_once NUNS_DIR . 'admin/class-admin.php';

/* ── Activation / Deactivation ──────────────────── */
register_activation_hook( __FILE__, [ 'NUNS_DB', 'install' ] );
register_activation_hook( __FILE__, [ 'NUNS_Plugin', 'on_activate' ] );
register_deactivation_hook( __FILE__, [ 'NUNS_Plugin', 'on_deactivate' ] );

/* ── Bootstrap ──────────────────────────────────── */
add_action( 'plugins_loaded', [ 'NUNS_Plugin', 'init' ] );

class NUNS_Plugin {

    public static function init() {
        new NUNS_Admin();
        new NUNS_Shortcode();
        add_action( 'nuns_cron_scrape', [ 'NUNS_Scraper', 'run' ] );
    }

    public static function on_activate() {
        NUNS_DB::install();
        if ( ! wp_next_scheduled( 'nuns_cron_scrape' ) ) {
            wp_schedule_event( time(), 'nuns_5min', 'nuns_cron_scrape' );
        }
        // Create PDF upload dir
        $upload = wp_upload_dir();
        $dir    = trailingslashit( $upload['basedir'] ) . NUNS_PDF_SUBDIR;
        if ( ! file_exists( $dir ) ) {
            wp_mkdir_p( $dir );
            file_put_contents( $dir . '/.htaccess', 'Options -Indexes' );
        }
    }

    public static function on_deactivate() {
        wp_clear_scheduled_hook( 'nuns_cron_scrape' );
    }
}

/* ── Custom cron interval: every 5 minutes ──────── */
add_filter( 'cron_schedules', function ( $s ) {
    $s['nuns_5min'] = [
        'interval' => 5 * MINUTE_IN_SECONDS,
        'display'  => __( 'Every 5 Minutes (NU Scraper)', 'nu-scraper' ),
    ];
    return $s;
} );

/* ── REST API Receiver (Vercel থেকে data নেবে) ── */
add_action( 'rest_api_init', function() {
    register_rest_route( 'nu-scraper/v1', '/push', [
        'methods'             => 'POST',
        'callback'            => 'nuns_receive_notices',
        'permission_callback' => '__return_true',
    ]);
});

function nuns_receive_notices( WP_REST_Request $request ) {
    $secret  = get_option( 'nuns_secret_key', 'nu-scraper-secret-2026' );
    $payload = $request->get_json_params();

    // Secret check
    if ( empty($payload['secret']) || $payload['secret'] !== $secret ) {
        return new WP_REST_Response(['error' => 'Unauthorized'], 401);
    }

    $notices  = $payload['notices'] ?? [];
    $inserted = 0;

    foreach ( $notices as $n ) {
        $result = NUNS_DB::insert([
            'title'        => $n['title']   ?? '',
            'publish_date' => $n['date']    ?? '',
            'pdf_url'      => $n['pdf_url'] ?? '',
            'source_url'   => 'https://www.nu.ac.bd/recent-news-notice.php',
        ]);
        if ( $result ) $inserted++;
    }

    // Update last scrape log
    update_option('nuns_last_scrape', [
        'status'   => 'success',
        'message'  => sprintf('Received %d notices from Vercel. %d new inserted.', count($notices), $inserted),
        'found'    => count($notices),
        'inserted' => $inserted,
        'time'     => current_time('mysql'),
    ]);

    return new WP_REST_Response([
        'success'  => true,
        'received' => count($notices),
        'inserted' => $inserted,
    ], 200);
}
