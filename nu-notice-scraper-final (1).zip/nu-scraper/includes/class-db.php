<?php
defined( 'ABSPATH' ) || exit;

class NUNS_DB {

    const TBL = 'nuns_notices';

    /* ── Schema ─────────────────────────────────── */
    public static function install() {
        global $wpdb;
        $t   = $wpdb->prefix . self::TBL;
        $col = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS {$t} (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title        TEXT            NOT NULL,
            publish_date VARCHAR(60)     NOT NULL DEFAULT '',
            pdf_url      TEXT            NOT NULL,
            local_pdf    TEXT            NOT NULL DEFAULT '',
            source_url   TEXT            NOT NULL,
            hash         VARCHAR(64)     NOT NULL,
            scraped_at   DATETIME        NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY   uq_hash (hash),
            KEY          idx_date (scraped_at)
        ) {$col};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        update_option( 'nuns_db_version', NUNS_VER );
    }

    /* ── Insert ─────────────────────────────────── */
    public static function insert( array $row ) {
        global $wpdb;
        $t    = $wpdb->prefix . self::TBL;
        $hash = md5( $row['title'] . '|' . $row['pdf_url'] );
        if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE hash=%s", $hash ) ) ) {
            return false; // already exists
        }
        $wpdb->insert( $t, [
            'title'        => sanitize_text_field( $row['title'] ),
            'publish_date' => sanitize_text_field( $row['publish_date'] ?? '' ),
            'pdf_url'      => esc_url_raw( $row['pdf_url'] ),
            'local_pdf'    => '',
            'source_url'   => esc_url_raw( $row['source_url'] ?? NUNS_SOURCE ),
            'hash'         => $hash,
            'scraped_at'   => current_time( 'mysql' ),
        ] );
        return $wpdb->insert_id;
    }

    /* ── Fetch list ─────────────────────────────── */
    public static function get_list( array $args = [] ) {
        global $wpdb;
        $t = $wpdb->prefix . self::TBL;
        $args = wp_parse_args( $args, [
            'search'  => '',
            'limit'   => 20,
            'offset'  => 0,
            'orderby' => 'id',
            'order'   => 'DESC',
        ] );

        $where = '1=1';
        $vals  = [];
        if ( $args['search'] ) {
            $where   .= ' AND title LIKE %s';
            $vals[]   = '%' . $wpdb->esc_like( $args['search'] ) . '%';
        }
        $ob    = in_array( $args['orderby'], ['id','title','publish_date','scraped_at'] ) ? $args['orderby'] : 'id';
        $ord   = $args['order'] === 'ASC' ? 'ASC' : 'DESC';
        $vals  = array_merge( $vals, [ (int)$args['limit'], (int)$args['offset'] ] );
        $sql   = "SELECT * FROM {$t} WHERE {$where} ORDER BY {$ob} {$ord} LIMIT %d OFFSET %d";
        return $wpdb->get_results( $wpdb->prepare( $sql, $vals ) );
    }

    /* ── Count ──────────────────────────────────── */
    public static function count( $search = '' ) {
        global $wpdb;
        $t = $wpdb->prefix . self::TBL;
        if ( $search ) {
            return (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$t} WHERE title LIKE %s",
                '%' . $wpdb->esc_like( $search ) . '%'
            ) );
        }
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" );
    }

    /* ── Single row ─────────────────────────────── */
    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}" . self::TBL . " WHERE id=%d", (int)$id
        ) );
    }

    /* ── Update local PDF path ──────────────────── */
    public static function set_local_pdf( $id, $path ) {
        global $wpdb;
        $wpdb->update( $wpdb->prefix . self::TBL, [ 'local_pdf' => $path ], [ 'id' => (int)$id ] );
    }

    /* ── Delete ─────────────────────────────────── */
    public static function delete( $id ) {
        global $wpdb;
        $row = self::get( $id );
        if ( $row && $row->local_pdf && file_exists( $row->local_pdf ) ) {
            @unlink( $row->local_pdf );
        }
        $wpdb->delete( $wpdb->prefix . self::TBL, [ 'id' => (int)$id ] );
    }

    /* ── All (for shortcode) ────────────────────── */
    public static function get_all_for_display( $limit = 0 ) {
        global $wpdb;
        $t   = $wpdb->prefix . self::TBL;
        $lim = $limit > 0 ? "LIMIT {$limit}" : '';
        return $wpdb->get_results( "SELECT * FROM {$t} ORDER BY id DESC {$lim}" );
    }
}
