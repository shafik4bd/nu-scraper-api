<?php
defined( 'ABSPATH' ) || exit;

class NUNS_Shortcode {

    public function __construct() {
        add_shortcode( 'nu_notices', [ $this, 'render' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue' ] );
    }

    public function maybe_enqueue() {
        global $post;
        if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'nu_notices' ) ) {
            wp_enqueue_style( 'nuns-public', NUNS_URL . 'public/css/public.css', [], NUNS_VER );
        }
    }

    public function render( $atts ) {
        $a = shortcode_atts([
            'limit'      => 0,
            'title'      => 'National University – Latest Notices',
            'show_date'  => 'yes',
            'show_no'    => 'yes',
        ], $atts, 'nu_notices' );

        $notices = NUNS_DB::get_all_for_display( (int) $a['limit'] );

        ob_start();
        include NUNS_DIR . 'public/views/table.php';
        return ob_get_clean();
    }
}
