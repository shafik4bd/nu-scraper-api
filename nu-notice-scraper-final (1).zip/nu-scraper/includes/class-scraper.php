<?php
defined( 'ABSPATH' ) || exit;

class NUNS_Scraper {

    // আপনার Vercel URL
    const VERCEL_URL = 'https://nu-scraper-api.vercel.app/api/scrape';
    const SECRET_KEY = 'nu-scraper-secret-2026';

    /* ── WordPress Cron এ চলবে ── */
    public static function run() {
        // Vercel কে call করো — সে scrape করে WP তে push করবে
        $url  = self::VERCEL_URL . '?key=' . self::SECRET_KEY;
        $resp = wp_remote_get( $url, [
            'timeout'   => 60,
            'sslverify' => false,
        ]);

        if ( is_wp_error( $resp ) ) {
            return self::log( 'error', 'Vercel call failed: ' . $resp->get_error_message(), 0, 0 );
        }

        $code = wp_remote_retrieve_response_code( $resp );
        $body = wp_remote_retrieve_body( $resp );
        $data = json_decode( $body, true );

        if ( $code !== 200 ) {
            return self::log( 'error', "Vercel returned HTTP {$code}", 0, 0 );
        }

        if ( ! empty( $data['error'] ) ) {
            return self::log( 'error', $data['error'], 0, 0 );
        }

        $found    = $data['total']              ?? 0;
        $inserted = $data['wp_push']['inserted'] ?? 0;

        return self::log(
            'success',
            sprintf( 'Vercel scraped %d notices. %d new saved.', $found, $inserted ),
            $found,
            $inserted
        );
    }

    private static function log( $status, $message, $found, $inserted ) {
        $data = [
            'status'   => $status,
            'message'  => $message,
            'found'    => $found,
            'inserted' => $inserted,
            'time'     => current_time( 'mysql' ),
        ];
        update_option( 'nuns_last_scrape', $data );
        return $data;
    }

    /* ── PDF Download ── */
    public static function download_pdf( $notice_id ) {
        $row = NUNS_DB::get( $notice_id );
        if ( ! $row ) return new WP_Error( 'not_found', 'Notice not found.' );

        if ( $row->local_pdf && file_exists( $row->local_pdf ) ) {
            $upload  = wp_upload_dir();
            $fileurl = str_replace( $upload['basedir'], $upload['baseurl'], $row->local_pdf );
            return [ 'success' => true, 'url' => $fileurl, 'message' => 'Already downloaded.' ];
        }

        $resp = wp_remote_get( $row->pdf_url, [ 'timeout' => 60, 'sslverify' => false ] );
        if ( is_wp_error( $resp ) ) return $resp;

        $code = wp_remote_retrieve_response_code( $resp );
        if ( $code !== 200 ) return new WP_Error( 'dl_fail', "PDF server returned HTTP {$code}" );

        $body = wp_remote_retrieve_body( $resp );
        if ( empty( $body ) ) return new WP_Error( 'dl_empty', 'File is empty.' );

        $upload   = wp_upload_dir();
        $dir      = trailingslashit( $upload['basedir'] ) . NUNS_PDF_SUBDIR;
        wp_mkdir_p( $dir );

        $basename = sanitize_file_name( $notice_id . '-' . basename( parse_url( $row->pdf_url, PHP_URL_PATH ) ) );
        if ( ! preg_match( '/\.pdf$/i', $basename ) ) $basename .= '.pdf';

        $filepath = $dir . '/' . $basename;
        if ( file_put_contents( $filepath, $body ) === false ) {
            return new WP_Error( 'write_fail', 'Could not write file.' );
        }

        $fileurl = str_replace( $upload['basedir'], $upload['baseurl'], $filepath );
        NUNS_DB::set_local_pdf( $notice_id, $filepath );

        return [ 'success' => true, 'url' => $fileurl, 'message' => 'Downloaded successfully.' ];
    }

    public static function download_all_pdfs() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT id FROM {$wpdb->prefix}nuns_notices
             WHERE (local_pdf = '' OR local_pdf IS NULL)
             ORDER BY id DESC LIMIT 50"
        );
        $done = 0;
        foreach ( $rows as $r ) {
            $res = self::download_pdf( $r->id );
            if ( ! is_wp_error( $res ) && ! empty( $res['success'] ) ) $done++;
        }
        return $done;
    }
}
