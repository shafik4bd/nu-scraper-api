<?php
// Runs when plugin is deleted from WP admin
defined('WP_UNINSTALL_PLUGIN') || exit;

global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}nuns_notices");
delete_option('nuns_db_version');
delete_option('nuns_last_scrape');
delete_option('nuns_auto_download_pdf');
delete_option('nuns_shortcode_title');
delete_option('nuns_shortcode_limit');
wp_clear_scheduled_hook('nuns_cron_scrape');
